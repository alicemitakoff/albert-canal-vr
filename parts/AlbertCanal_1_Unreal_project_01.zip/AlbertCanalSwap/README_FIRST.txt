Albert Canal battery swap: Unreal Engine 5.8 project

Windows
  1. Install Unreal Engine 5.8 from the Epic Games Launcher (tick Android under Target Platforms if you want the Quest app)
     and Visual Studio 2022 with the "Game development with C++" workload.
  2. Put Cesium for Unreal in the Plugins folder (see Plugins/PUT_CESIUM_HERE.txt).
  3. Right click AlbertCanalSwap.uproject > Generate Visual Studio project files.
  4. Double click AlbertCanalSwap.uproject. Answer Yes to rebuild the modules. The first build takes several minutes.
  5. Press Play. Space moves the story on, Tab changes viewpoint, right mouse looks around.

Mac
  Same steps with Xcode. If Cesium fails to compile with warnings treated as errors, copy the three files from
  ../Cesium_Mac_patch_only/Source over the same files in Plugins/CesiumForUnreal/Source.

Full guide: the Windows guide (PDF) "Albert Canal battery swap in Unreal, Cesium, Blender and Meta Quest 3".
Code updated on 14 October 2026 to match the web version (battery bay on deck, mitre gates, departure path, wake, VR movement).
