import unreal, math, json
PTS=json.loads('''{"48.0": [5.047667107971952, 51.10858326702897], "48.1": [5.049040101976579, 51.10832698827017], "48.2": [5.050413095981207, 51.108070709511374], "48.3": [5.051786089985835, 51.107814430752576], "48.4": [5.053159856586823, 51.10755987166899], "48.5": [5.054543191095526, 51.10732660920879], "48.6": [5.055923880597287, 51.107087348228276], "48.7": [5.057303445056685, 51.106845535802854], "48.8": [5.058683009516083, 51.10660372337744], "48.9": [5.0600625739754825, 51.106361910952025], "49.0": [5.061442138434881, 51.10612009852661], "49.1": [5.062821702894279, 51.105878286101195], "49.2": [5.064201267353678, 51.10563647367577], "49.3": [5.065580831813076, 51.10539466125036], "49.4": [5.066960396272474, 51.10515284882494], "49.5": [5.068339960731873, 51.10491103639953], "49.6": [5.069719355025703, 51.10466892301988], "49.7": [5.071098686715139, 51.10442669891832], "49.8": [5.072478018404576, 51.10418447481676], "49.9": [5.073857350094013, 51.1039422507152], "50.0": [5.0752369290778185, 51.10370066116107], "50.1": [5.076616515475737, 51.10345909063126], "50.2": [5.077996101873657, 51.103217520101445], "50.3": [5.0793756882715755, 51.102975949571636], "50.4": [5.080755274669494, 51.10273437904183], "50.5": [5.082134861067414, 51.10249280851201], "50.6": [5.083500987159778, 51.102223346709295], "50.7": [5.084862878861137, 51.1019451107703], "50.8": [5.086224770562496, 51.10166687483132], "50.9": [5.087586662263854, 51.10138863889233], "51.0": [5.0889485539652135, 51.101110402953346], "51.1": [5.090310445666572, 51.10083216701435], "51.2": [5.091672337367931, 51.10055393107537], "51.3": [5.09303422906929, 51.10027569513638], "51.4": [5.094396120770648, 51.09999745919739], "51.5": [5.095758012472007, 51.099719223258404], "51.6": [5.097125069364296, 51.099451315550006], "51.7": [5.098493493151644, 51.09918614106242], "51.8": [5.099861916938993, 51.09892096657483], "51.9": [5.1012303407263415, 51.09865579208724], "52.0": [5.10259876451369, 51.098390617599655], "52.1": [5.103975601284683, 51.098143377854406], "52.2": [5.105353751872247, 51.09789893889455], "52.3": [5.1067321301930395, 51.097655035934814], "52.4": [5.108118922145082, 51.09743074179876], "52.5": [5.109505714097125, 51.09720644766271], "52.6": [5.110908138176063, 51.09702591120976], "52.7": [5.112314640397557, 51.096856880048584], "52.8": [5.113721142619051, 51.096687848887406], "52.9": [5.115127644840545, 51.09651881772622], "53.0": [5.11653414706204, 51.09634978656504], "53.1": [5.11793942156772, 51.09617685306605], "53.2": [5.119344433446067, 51.09600308479685], "53.3": [5.120749445324415, 51.09582931652765], "53.4": [5.122154457202762, 51.09565554825845], "53.5": [5.123559469081109, 51.09548177998926], "53.6": [5.124965442489903, 51.09531116999621], "53.7": [5.126371591081202, 51.09514113541366], "53.8": [5.127777739672501, 51.094971100831124], "53.9": [5.129170187566477, 51.09476227268569]}''')
eas=unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
A={a.get_actor_label():a for a in eas.get_all_level_actors()}
geo=[a for a in eas.get_all_level_actors() if a.get_class().get_name()=="CesiumGeoreference"][0]
hub=A["SwapHub_Kwaadmechelen"]; lock=A["Lock_Kwaadmechelen"]; barge=A["EBarge_CMA_CGM_ALBERT"]
FPS=30
def F(s): return unreal.FrameNumber(int(round(s*FPS)))
# ---------- barge: detach to world ----------
dock_world=barge.get_actor_transform()
if barge.get_attach_parent_actor(): barge.detach_from_actor(unreal.DetachmentRule.KEEP_WORLD,unreal.DetachmentRule.KEEP_WORLD,unreal.DetachmentRule.KEEP_WORLD)
def U(km):
    k=min(PTS.keys(),key=lambda x:abs(float(x)-km)); lo,la=PTS[k]
    return geo.transform_longitude_latitude_height_position_to_unreal(unreal.Vector(lo,la,0))
def interp(km):
    a=math.floor(km*10)/10; b=a+0.1; f=(km-a)/0.1
    pa=U(a); pb=U(b); return unreal.Vector(pa.x+(pb.x-pa.x)*f,pa.y+(pb.y-pa.y)*f,0), (pb.x-pa.x,pb.y-pa.y)
def barge_at(km,lat_m,z=-300):
    c,(tx,ty)=interp(km); L=math.hypot(tx,ty); tx/=L; ty/=L
    nx,ny=ty,-tx
    loc=unreal.Vector(c.x+nx*lat_m*100,c.y+ny*lat_m*100,z)
    yaw=math.degrees(math.atan2(ty,tx))+90
    return loc,yaw
def lock_at(xl,z=-300):
    loc=lock.get_actor_transform().transform_location(unreal.Vector(xl*100,0,z))
    return loc, lock.get_actor_rotation().yaw+90
dl=dock_world.translation; dyaw=dock_world.rotation.rotator().yaw
def unwrap(prev,y):
    while y-prev>180: y-=360
    while y-prev<-180: y+=360
    return y
BK=[(0,)+barge_at(49.4,0),(8,)+barge_at(50.3,22),(16,dl,dyaw),(46.5,dl,dyaw),(52,)+barge_at(51.25,25),(58,)+barge_at(51.75,0),
    (64,)+lock_at(-300),(70,)+lock_at(-235),(79,)+lock_at(-85),(84,)+lock_at(-85),(104,)+lock_at(-85,700),(110,)+lock_at(-85,700),(125,)+lock_at(330,700)]
# ---------- proxies for the battery hand-over ----------
def dup(src,label,parent,rel_loc,rel_yaw):
    old=A.get(label)
    if old: eas.destroy_actor(old)
    d=eas.duplicate_actor(src,None,unreal.Vector(0,0,0)); d.set_actor_label(label)
    d.attach_to_actor(parent,"",unreal.AttachmentRule.KEEP_WORLD,unreal.AttachmentRule.KEEP_WORLD,unreal.AttachmentRule.KEEP_WORLD,False)
    d.set_actor_relative_location(rel_loc,False,False); d.set_actor_relative_rotation(unreal.Rotator(0,0,rel_yaw),False,False)
    return d
spr=A["Crane_spreader"]; trol=A["Crane_trolley"]; gant=A["Crane_structure"]
battA=A["Battery_A"]; hb1=A["Hub_Battery_1"]
battA_rel=battA.get_editor_property("root_component").get_editor_property("relative_location")
battA_relrot=battA.get_editor_property("root_component").get_editor_property("relative_rotation")
loadA=dup(battA,"Swap_LoadA",spr,unreal.Vector(0,0,-259.1),90)
dockA=dup(battA,"Swap_DockA",hub,unreal.Vector(1350,-2400,235),-90)
loadC=dup(hb1,"Swap_LoadC",spr,unreal.Vector(0,0,-259.1),-90)
newA=dup(hb1,"Swap_BargeNewA",barge,battA_rel,battA_relrot.yaw)
# hub-local position of battery A while docked
hubT=hub.get_actor_transform()
aL=hubT.inverse_transform_location(battA.get_actor_location())
TOPZ=1400.0; pickA=aL.z+259.1+0.5
SK=[(17,0,640,680),(19,aL.x,aL.y,TOPZ),(21,aL.x,aL.y,pickA),(21.6,aL.x,aL.y,pickA),(23.5,aL.x,aL.y,TOPZ),(26.5,1350,-2400,TOPZ),(28.5,1350,-2400,235+259.6),(29.2,1350,-2400,235+259.6),
    (30.8,1350,-2400,TOPZ),(33.5,-1350,-2400,TOPZ),(35.5,-1350,-2400,235+259.6),(36.2,-1350,-2400,235+259.6),(37.8,-1350,-2400,TOPZ),(41,aL.x,aL.y,TOPZ),(43,aL.x,aL.y,pickA),(43.6,aL.x,aL.y,pickA),(45,aL.x,aL.y,TOPZ),(47,0,640,TOPZ)]
# ---------- sequence asset ----------
path="/Game/Sequences/BargeJourney_Kwaadmechelen"
if unreal.EditorAssetLibrary.does_asset_exist(path): unreal.EditorAssetLibrary.delete_asset(path)
seq=unreal.AssetToolsHelpers.get_asset_tools().create_asset("BargeJourney_Kwaadmechelen","/Game/Sequences",unreal.LevelSequence,unreal.LevelSequenceFactoryNew())
seq.set_display_rate(unreal.FrameRate(FPS,1)); seq.set_tick_resolution(unreal.FrameRate(FPS,1))
seq.set_playback_start(0); seq.set_playback_end(int(126*FPS))
def ttrack(actor,keys):
    b=seq.add_possessable(actor); tr=b.add_track(unreal.MovieScene3DTransformTrack); s=tr.add_section(); s.set_range(0,int(126*FPS))
    ch=s.get_all_channels()
    for k in keys:
        t=k[0]; loc=k[1]; yaw=k[2] if len(k)>2 else None
        ch[0].add_key(F(t),loc.x); ch[1].add_key(F(t),loc.y); ch[2].add_key(F(t),loc.z)
        if yaw is not None: ch[5].add_key(F(t),yaw)
    return b
def vis(actor,keys):
    b=seq.add_possessable(actor); tr=b.add_track(unreal.MovieSceneVisibilityTrack); tr.set_property_name_and_path("bHiddenInGame","bHiddenInGame")
    s=tr.add_section(); s.set_range(0,int(126*FPS)); c=s.get_all_channels()[0]
    for t,hidden in keys: c.add_key(F(t),hidden)
# barge
prev=None; bk=[]
for t,loc,yaw in BK:
    yaw=yaw if prev is None else unwrap(prev,yaw); prev=yaw; bk.append((t,loc,yaw))
ttrack(barge,bk)
# crane
ttrack(gant,[(t,unreal.Vector(x,0,0)) for t,x,y,z in SK])
ttrack(trol,[(t,unreal.Vector(x,y,0)) for t,x,y,z in SK])
ttrack(spr,[(t,unreal.Vector(x,y,z)) for t,x,y,z in SK])
# battery hand-over visibility (hidden flag)
vis(battA,[(0,False),(21.6,True)]); vis(A["Battery_A_LED"],[(0,False),(21.6,True)])
vis(loadA,[(0,True),(21.6,False),(29.2,True)]); vis(dockA,[(0,True),(29.2,False)])
vis(hb1,[(0,False),(36.2,True)]); vis(A["Hub_Battery_1_LED"],[(0,False),(36.2,True)])
vis(loadC,[(0,True),(36.2,False),(43.6,True)]); vis(newA,[(0,True),(43.6,False)])
# lock: gates and water
gd=A["Gate_PushTow_Down"]; gu=A["Gate_PushTow_Up"]; wc=A["Water_Chamber_PushTow"]
rl=lambda a: a.get_editor_property("root_component").get_editor_property("relative_location")
gdl=rl(gd); gul=rl(gu); wcl=rl(wc)
ttrack(gd,[(0,unreal.Vector(gdl.x,gdl.y,gdl.z+2300)),(79,unreal.Vector(gdl.x,gdl.y,gdl.z+2300)),(84,gdl)])
ttrack(wc,[(0,wcl),(84,wcl),(104,unreal.Vector(wcl.x,wcl.y,wcl.z+1000))])
ttrack(gu,[(0,gul),(104,gul),(109,unreal.Vector(gul.x,gul.y,gul.z+1700))])
unreal.EditorAssetLibrary.save_loaded_asset(seq)
unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).save_current_level()
print("sequence ok", len(bk), aL)
