#!/bin/sh
cd "`dirname "$0"`"
AFS=./osx-x64/UnrealAndroidFileTool
ADB=adb
if ! command -v -- "$ADB" >/dev/null 2>&1; then
	STUDIO_SDK_PATH=$ANDROID_HOME
	if [ ! -d "$STUDIO_SDK_PATH" ]; then
		STUDIO_SDK_PATH=~/Library/Android/sdk
		if [ ! -d "$STUDIO_SDK_PATH" ]; then
			echo Unable to locate local Android SDK location.
			exit 1
		fi
	fi
	ADB=$STUDIO_SDK_PATH/platform-tools/adb
fi
DEVICE=
if [ "$1" != "" ]; then DEVICE="-s $1"; fi
echo
echo Uninstalling existing application. Failures here can almost always be ignored.
$ADB $DEVICE uninstall com.aimovation.albertcanalswap
echo
echo Installing existing application. Failures here indicate a problem with the device \(connection or storage permissions\) and are fatal.
$ADB $DEVICE install AlbertCanalSwap-arm64.apk
if [ $? -eq 0 ]; then
	echo
	$ADB $DEVICE shell pm list packages com.aimovation.albertcanalswap
	$ADB $DEVICE shell pm grant com.aimovation.albertcanalswap android.permission.FOREGROUND_SERVICE >/dev/null 2>&1
	$ADB $DEVICE shell pm grant com.aimovation.albertcanalswap android.permission.FOREGROUND_SERVICE_DATA_SYNC >/dev/null 2>&1
	$ADB $DEVICE shell pm grant com.aimovation.albertcanalswap android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
	echo
	echo Removing old data. Failures here are usually fine - indicating the files were not on the device.
	$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/UnrealGame/AlbertCanalSwap'
	$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/UnrealGame/UECommandLine.txt'
	$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/obb/com.aimovation.albertcanalswap'
	$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/Android/obb/com.aimovation.albertcanalswap'
	$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/Download/obb/com.aimovation.albertcanalswap'
	echo
	echo Installing new data. Failures here indicate storage problems \(missing SD card or bad permissions\) and are fatal.
	STORAGE=$(echo "`$ADB $DEVICE shell 'echo $EXTERNAL_STORAGE'`" | cat -v | tr -d '^M')
	$AFS $DEVICE -p com.aimovation.albertcanalswap -k 5131E1EB9D4B5D21F793FF9E804AD750 push main.1.com.aimovation.albertcanalswap.obb '^mainobb'
	if [ $? -eq 0 ]; then




$AFS $DEVICE -p com.aimovation.albertcanalswap -k 5131E1EB9D4B5D21F793FF9E804AD750 stop-all
	echo Grant READ_EXTERNAL_STORAGE and WRITE_EXTERNAL_STORAGE to the apk for reading OBB or game file in external storage.
	$ADB $DEVICE shell pm grant com.aimovation.albertcanalswap android.permission.READ_EXTERNAL_STORAGE >/dev/null 2>&1
	$ADB $DEVICE shell pm grant com.aimovation.albertcanalswap android.permission.WRITE_EXTERNAL_STORAGE >/dev/null 2>&1

		echo
		echo Installation successful
		exit 0
	fi
fi
echo
echo There was an error installing the game or the obb file. Look above for more info.
echo
echo Things to try:
echo 'Check that the device (and only the device) is listed with \"$ADB devices\" from a command prompt.'
echo Make sure all Developer options look normal on the device
echo Check that the device has an SD card.
exit 1
