#!/bin/sh
cd "`dirname "$0"`"
ADB=adb
if ! command -v -- "$ADB" >/dev/null 2>&1; then
	STUDIO_SDK_PATH=$ANDROID_HOME
	if [ ! -d "$STUDIO_SDK_PATH" ]; then
		STUDIO_SDK_PATH=~/Library/Android/sdk
		if [ ! -d "$STUDIO_SDK_PATH" ]; then
			echo Unable to locate local Android SDK location.
			exit 1
		fi
	fi
	ADB=$STUDIO_SDK_PATH/platform-tools/adb
fi
DEVICE=
if [ "$1" != "" ]; then DEVICE="-s $1"; fi
echo
echo Uninstalling existing application. Failures here can almost always be ignored.
$ADB $DEVICE uninstall com.aimovation.albertcanalswap
echo
echo Removing old data. Failures here are usually fine - indicating the files were not on the device.
$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/UnrealGame/AlbertCanalSwap'
$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/UnrealGame/UECommandLine.txt'
$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/obb/com.aimovation.albertcanalswap'
$ADB $DEVICE shell 'rm -r $EXTERNAL_STORAGE/Android/obb/com.aimovation.albertcanalswap'
echo
echo Uninstall completed
exit 0
