@echo off
rem Installs the Albert Canal battery swap app on a Meta Quest 3 connected by USB (developer mode on).
cd /d "%~dp0"
set ADB=adb
where adb >nul 2>nul || set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
echo Removing any older version...
"%ADB%" uninstall com.aimovation.albertcanalswap >nul 2>nul
echo Installing the app...
"%ADB%" install AlbertCanalSwap-arm64.apk || goto fail
echo Copying the scene data (155 MB)...
"%ADB%" shell mkdir -p /sdcard/Android/obb/com.aimovation.albertcanalswap
"%ADB%" push main.1.com.aimovation.albertcanalswap.obb /sdcard/Android/obb/com.aimovation.albertcanalswap/ || goto fail
echo.
echo Done. In the headset open Library, then Unknown sources, then AlbertCanalSwap.
pause
exit /b 0
:fail
echo.
echo Something went wrong. Check the USB cable and accept "Allow USB debugging" inside the headset, then run this again.
pause
exit /b 1
